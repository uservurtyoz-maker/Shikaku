package com.example.shikaku

object Solver {
    data class Rect4(val r0: Int, val c0: Int, val h: Int, val w: Int)

    /** free[r][c] = cell exists; clue[r][c] > 0 = number in cell. Returns rectangles or null. */
    fun solve(rows: Int, cols: Int, free: Array<BooleanArray>, clue: Array<IntArray>): List<Rect4>? {
        val owner = Array(rows) { IntArray(cols) { -1 } }
        val out = ArrayList<Rect4>()

        fun fits(r0: Int, c0: Int, h: Int, w: Int): Boolean {
            if (r0 + h > rows || c0 + w > cols) return false
            var found = 0
            var value = 0
            for (r in r0 until r0 + h) for (c in c0 until c0 + w) {
                if (!free[r][c] || owner[r][c] != -1) return false
                if (clue[r][c] > 0) { found++; value = clue[r][c] }
            }
            return found == 1 && value == h * w
        }

        fun rec(): Boolean {
            var fr = -1
            var fc = -1
            loop@ for (r in 0 until rows) for (c in 0 until cols) {
                if (free[r][c] && owner[r][c] == -1) { fr = r; fc = c; break@loop }
            }
            if (fr == -1) return true

            for (h in 1..(rows - fr)) for (w in 1..(cols - fc)) {
                if (!fits(fr, fc, h, w)) continue
                val id = out.size
                out.add(Rect4(fr, fc, h, w))
                for (r in fr until fr + h) for (c in fc until fc + w) owner[r][c] = id
                if (rec()) return true
                for (r in fr until fr + h) for (c in fc until fc + w) owner[r][c] = -1
                out.removeAt(out.size - 1)
            }
            return false
        }

        return if (rec()) out else null
    }
}
