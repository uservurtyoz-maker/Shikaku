package com.example.shikaku

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.text.Text

data class Analysis(
    val ok: Boolean,
    val message: String,
    val board: Rect?,
    val pw: Float,
    val ph: Float,
    val solution: List<Solver.Rect4>
)

/**
 * Finds the play board on a screenshot.
 * Assumes: white cells on a beige background, cells separated by small gaps,
 * and a header with the size in the form "C × R" (columns × rows).
 */
object GridDetector {
    // Ratio of cell width to cell pitch (cell + gap). Gap is about 14% of the pitch.
    private const val K = 0.86f

    private fun isWhite(p: Int): Boolean {
        val r = (p shr 16) and 0xFF
        val g = (p shr 8) and 0xFF
        val b = p and 0xFF
        return r >= 240 && g >= 240 && b >= 240
    }

    private fun fail(msg: String) = Analysis(false, msg, null, 0f, 0f, emptyList())

    fun analyze(bmp: Bitmap, text: Text): Analysis {
        val header = Regex("(\\d+)\\s*[×xXх*]\\s*(\\d+)").find(text.text)
            ?: return fail("Не нашёл размер поля вида «6 × 8» на экране")
        val cols = header.groupValues[1].toInt()
        val rows = header.groupValues[2].toInt()
        if (cols < 1 || rows < 1 || cols > 30 || rows > 30) return fail("Странный размер поля: $cols × $rows")

        // Search only the middle of the screen: skip the top bar and the bottom buttons (white circles)
        val y0 = (bmp.height * 0.22).toInt()
        val y1 = (bmp.height * 0.82).toInt()
        var minX = Int.MAX_VALUE; var minY = Int.MAX_VALUE
        var maxX = -1; var maxY = -1
        var y = y0
        while (y < y1) {
            var x = 0
            while (x < bmp.width) {
                if (isWhite(bmp.getPixel(x, y))) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
                x += 2
            }
            y += 2
        }
        if (maxX < 0) return fail("Белые клетки не найдены")

        val bw = (maxX - minX + 1).toFloat()
        val bh = (maxY - minY + 1).toFloat()
        val pw = bw / (cols - 1 + K)
        val ph = bh / (rows - 1 + K)

        val free = Array(rows) { BooleanArray(cols) }
        for (r in 0 until rows) for (c in 0 until cols) {
            // Sample the top-middle of each cell: it is never covered by the digit
            val x = (minX + (c + 0.43f) * pw).toInt().coerceIn(0, bmp.width - 1)
            val yy = (minY + (r + 0.08f) * ph).toInt().coerceIn(0, bmp.height - 1)
            free[r][c] = isWhite(bmp.getPixel(x, yy))
        }

        val clue = Array(rows) { IntArray(cols) }
        for (block in text.textBlocks) for (line in block.lines) for (el in line.elements) {
            val t = el.text.trim()
            if (!Regex("\\d{1,3}").matches(t)) continue
            val box = el.boundingBox ?: continue
            val cx = box.centerX()
            val cy = box.centerY()
            if (cx < minX || cx > maxX || cy < minY || cy > maxY) continue
            val c = ((cx - minX) / pw).toInt().coerceIn(0, cols - 1)
            val r = ((cy - minY) / ph).toInt().coerceIn(0, rows - 1)
            clue[r][c] = t.toInt()
        }

        var freeCount = 0
        var clueSum = 0
        for (r in 0 until rows) for (c in 0 until cols) {
            if (free[r][c]) freeCount++
            clueSum += clue[r][c]
        }
        if (clueSum != freeCount) {
            return fail("Распознавание: клеток $freeCount, сумма чисел $clueSum. Проверьте скриншот.")
        }

        val sol = Solver.solve(rows, cols, free, clue)
            ?: return fail("Решение не найдено")

        return Analysis(true, "Прямоугольников: ${sol.size}", Rect(minX, minY, maxX, maxY), pw, ph, sol)
    }
}
