package com.example.shikaku

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

class OverlayView(context: Context) : View(context) {
    var rects: List<RectF> = emptyList()

    private val fill = Paint().apply { style = Paint.Style.FILL }
    private val stroke = Paint().apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f
        color = Color.BLACK
    }
    private val colors = intArrayOf(
        Color.argb(120, 255, 99, 71),
        Color.argb(120, 60, 179, 113),
        Color.argb(120, 65, 105, 225),
        Color.argb(120, 255, 215, 0),
        Color.argb(120, 218, 112, 214),
        Color.argb(120, 0, 206, 209),
        Color.argb(120, 255, 140, 0),
        Color.argb(120, 154, 205, 50)
    )

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        rects.forEachIndexed { i, r ->
            fill.color = colors[i % colors.size]
            canvas.drawRect(r, fill)
            canvas.drawRect(r, stroke)
        }
    }
}
