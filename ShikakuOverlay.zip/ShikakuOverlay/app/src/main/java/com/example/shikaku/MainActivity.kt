package com.example.shikaku

import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { res ->
        if (res.resultCode == RESULT_OK && res.data != null) {
            val i = Intent(this, ShikakuService::class.java)
                .putExtra(ShikakuService.EXTRA_CODE, res.resultCode)
                .putExtra(ShikakuService.EXTRA_DATA, res.data)
            ContextCompat.startForegroundService(this, i)
            Toast.makeText(this, "Откройте игру и нажмите «Найти»", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "Запись экрана не разрешена", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 48, 48, 48)
        }
        val info = TextView(this).apply {
            text = "1. Разрешите отображение поверх других окон.\n" +
                "2. Запустите захват экрана.\n" +
                "3. Откройте игру и нажмите «Найти» на оверлее."
            textSize = 16f
        }
        val btnOverlay = Button(this).apply {
            text = "1. Разрешить оверлей"
            setOnClickListener {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
        }
        val btnCapture = Button(this).apply {
            text = "2. Запустить захват"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Сначала разрешите оверлей", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projectionLauncher.launch(mpm.createScreenCaptureIntent())
            }
        }

        layout.addView(info)
        layout.addView(btnOverlay)
        layout.addView(btnCapture)
        setContentView(layout)
    }
}
